clc;
clear;
close all;

% تعریف تابع تبدیل G(s)
num = [0.1 -0.2];  % صورت
den = [1 0.9 9 0]; % مخرج
G = tf(num, den);

% رسم مکان هندسی ریشه‌ها
figure;
rlocus(G);
title('Root Locus');
