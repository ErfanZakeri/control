clc; clear; close all;
load('Data.mat');

frequency = Data.omega; 
magnitude = Data.magnitude; 
phase = Data.phase; 

% Convert magnitude to dB
magnitude_dB = 20 * log10(magnitude);

figure;

% Plot Bode Magnitude Plot (Blue)
subplot(2,1,1);
semilogx(frequency, magnitude_dB, 'b');
xlabel('فرکانس (rad/s)');
ylabel('اندازه (dB)');
title('Bode Diagram-Magnitude');
grid on;

% Plot Bode Phase Plot (Red)
subplot(2,1,2);
semilogx(frequency, phase, 'r');
xlabel('فرکانس (rad/s)');
ylabel('فاز (degrees)');
title('Bode Diagram-Phase');
grid on;